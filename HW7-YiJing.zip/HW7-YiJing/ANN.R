rm(list=ls())
file<-file.choose()
cancer<-read.csv(file)
cancer<-data.frame(lapply(na.omit(cancer),as.numeric))
idx<-sort(sample(nrow(cancer),as.integer(0.75*nrow(cancer))))
training<-cancer[idx,]
testing<-cancer[-idx,]
#install.packages("neuralnet")
library("neuralnet")

#Perform Ann ALgorithm
ann<-neuralnet(diagnosis~.,data = training[-1],hidden = 5,threshold = 0.01,act.fct = "logistic")

plot(ann)

Prediction<-predict(ann,testing)
Prediction
Prediction_cat<-ifelse(Prediction<1.5,'1','2')

table(Actual=testing[,2],predition=Prediction_cat)

#Measure error rate
wrong<- (testing[,2]!=Prediction_cat)
error_rate<-sum(wrong)/length(wrong)
error_rate


