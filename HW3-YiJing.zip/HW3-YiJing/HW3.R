## remove all objects
rm(list=ls())

installed.packages()
#install.packages("kknn")

file<-file.choose()
data<-read.csv(file,na.strings = "?")
library(kknn)
?kknn()
data_delete<-na.omit(data)
data_delete$Class<-factor(data_delete$Class,levels = c(2,4),labels = c("benign","malignant"))
idx<-sample(2,nrow(data_delete),replace = TRUE,prob = c(0.7,0.3))
trainData <- data_delete[idx==1,]
trainData
testData <- data_delete[idx==2,]

model<-kknn(Class ~ .,trainData,testData,k=3)
summary(model)
fit <- fitted(model)
table(testData$Class,fit)
true_class<-(fit==testData$Class)
accuracy<-sum(true_class)/length(true_class)

model2<-kknn(Class ~ .,trainData,testData,k=5)
summary(model2)
fit <- fitted(model2)
table(testData$Class,fit)
true_class2<-(fit==testData$Class)
accuracy2<-sum(true_class2)/length(true_class2)

model3<-kknn(Class ~ .,trainData,testData,k=10)
summary(model3)
fit <- fitted(model3)
table(testData$Class,fit)
true_class3<-(fit==testData$Class)
accuracy3<-sum(true_class3)/length(true_class3)

