
rm(list=ls())

file<-file.choose()
bc <-  read.csv(file,
                na.strings = "?",
                colClasses=c("Sample"="character",
                             "F1"="factor","F2"="factor","F3"="factor",
                             "F4"="factor","F5"="factor","F6"="factor",
                             "F7"="factor","F8"="factor","F9"="factor",
                             "Class"="factor"))

#install.packages("rpart")
#install.packages("rpart.plot")    
#install.packages("rattle")        
#install.packages("RColorBrewer")   
library(rpart)
library(rpart.plot)  		
library(rattle)          
library(RColorBrewer)     

data_delete<-na.omit(bc)
data_delete$Class<-factor(data_delete$Class,levels = c(2,4),labels = c("benign","malignant"))
idx<-sample(2,nrow(data_delete),replace = TRUE,prob = c(0.7,0.3))
training <- data_delete[idx==1,]
training
test <- data_delete[idx==2,]
?rpart()

CART_class<-rpart( Class~.,data=training[,-1])
CART_predict2<-predict(CART_class,test, type="class")
df<-as.data.frame(cbind(test,CART_predict2))
table(Actual=test[,"Class"],CART=CART_predict2)

CART_wrong<-sum(test[,"Class"]!=CART_predict2)

error_rate=CART_wrong/length(test$Class)
error_rate






