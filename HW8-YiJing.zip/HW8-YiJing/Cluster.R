rm(list=ls())
file<-file.choose()
cancer<-read.csv(file)

summary(cancer)
summary(cancer$diagnosis)

cancer<-na.omit(cancer)
cancer<-cancer[-1]
cancer_dist<-dist(cancer[,-1])

#Perform Hclust Algorithm
hclust_resutls<-hclust(cancer_dist )
plot(hclust_resutls)
hclust_2<-cutree(hclust_resutls,2)
table(Cluster=hclust_2,Actual=cancer[,1])

#Perform K mean Algorithm
kmeans_2<- kmeans(cancer[,-1],2,nstart = 10)
kmeans_2$cluster
table(kmeans_2$cluster,Actual=cancer[,1])
